# PowerShell скрипты

- `scripts/local_install.ps1` — установка локального сервиса (как служба через NSSM), фаерволл, исключения Defender.
- `scripts/remote_install.ps1` — установка удалённого сервиса.
- `scripts/service_control.ps1` — старт/стоп/рестарт службы.
- `scripts/local_configure_env.ps1` — быстрое заполнение `.env` локального.

Примеры:
```powershell
# Локальный
powershell -ExecutionPolicy Bypass -File .\scripts\local_install.ps1 -InstallDir "C:\LocalYOLOv3" -Port 8010 -ServiceName "LocalYOLOv3" -UseExe:$false

# Удалённый
powershell -ExecutionPolicy Bypass -File .\scripts\remote_install.ps1 -InstallDir "C:\RemoteYOLOv3" -Port 8020 -ServiceName "RemoteYOLOv3" -UseExe:$false
```
