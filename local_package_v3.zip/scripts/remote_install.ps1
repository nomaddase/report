
param(
  [string]$InstallDir = "C:\Program Files\RemoteYOLOTrainer",
  [int]$Port = 8020,
  [string]$ServiceName = "RemoteYOLOTrainer",
  [string]$PythonExe = "python",
  [switch]$UseExe
)

Write-Host "Installing Remote Trainer to $InstallDir ..."
New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null

Copy-Item -Path ".\remote_backend\*" -Destination $InstallDir -Recurse -Force
Copy-Item -Path ".\vendor" -Destination $InstallDir -Recurse -Force -ErrorAction SilentlyContinue

if (!(Test-Path "$InstallDir\.env")) {
  Copy-Item "$InstallDir\.env.example" "$InstallDir\.env"
}

Write-Host "Configuring Windows Firewall ..."
netsh advfirewall firewall add rule name="$ServiceName" dir=in action=allow protocol=TCP localport=$Port | Out-Null

Add-MpPreference -ExclusionPath "$InstallDir\datasets","$InstallDir\models","$InstallDir\logs" -ErrorAction SilentlyContinue

$Nssm = Join-Path $InstallDir "vendor\nssm.exe"
if (!(Test-Path $Nssm)) {
  Write-Warning "nssm.exe не найден в $Nssm. Загрузите NSSM и поместите nssm.exe в vendor."
  exit 1
}

if ($UseExe) {
  $Exe = Join-Path $InstallDir "RemoteTrainerService.exe"
  if (!(Test-Path $Exe)) {
    Write-Warning "EXE не найден: $Exe"
    exit 1
  }
  & $Nssm install $ServiceName $Exe
  & $Nssm set $ServiceName AppDirectory $InstallDir
} else {
  & $Nssm install $ServiceName "$PythonExe" " -m uvicorn app:app --host 0.0.0.0 --port $Port"
  & $Nssm set $ServiceName AppDirectory $InstallDir
}

& $Nssm set $ServiceName AppStdout "$env:ProgramData\$ServiceName\logs\stdout.log"
& $Nssm set $ServiceName AppStderr "$env:ProgramData\$ServiceName\logs\stderr.log"
& $Nssm set $ServiceName Start SERVICE_AUTO_START
& $Nssm set $ServiceName AppRestartDelay 5000

Write-Host "Starting service ..."
& $Nssm start $ServiceName
Write-Host "Done."
