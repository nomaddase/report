
param(
  [ValidateSet("start","stop","restart","status")][string]$Action,
  [string]$ServiceName
)
switch ($Action) {
  "start"   { Start-Service $ServiceName }
  "stop"    { Stop-Service $ServiceName }
  "restart" { Restart-Service $ServiceName }
  "status"  { Get-Service $ServiceName }
}
