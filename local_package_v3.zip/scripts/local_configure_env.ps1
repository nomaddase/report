
param(
  [string]$EnvPath = ".\.env",
  [string]$RemoteUrl = "http://127.0.0.1:8020",
  [string]$ApiToken = "supersecret"
)
if (!(Test-Path $EnvPath)) {
  if (Test-Path ".\.env.example") { Copy-Item ".\.env.example" $EnvPath }
  else { New-Item -ItemType File -Path $EnvPath | Out-Null }
}
(Get-Content $EnvPath) |
  ForEach-Object {
    $_ -replace "^REMOTE_BASE_URL=.*$", "REMOTE_BASE_URL=$RemoteUrl" `
       -replace "^API_TOKEN=.*$", "API_TOKEN=$ApiToken"
  } | Set-Content $EnvPath
Write-Host "Updated $EnvPath"
