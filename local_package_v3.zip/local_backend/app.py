
import os, io, cv2, time, json, zipfile, shutil, queue, logging, threading, tempfile, pathlib
import typing as T
import numpy as np, requests, psutil, base64
from datetime import datetime
from pydantic_settings import BaseSettings
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, BackgroundTasks, HTTPException, Depends, Header
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware
from ultralytics import YOLO
try:
    from nacl.signing import VerifyKey
    from nacl.exceptions import BadSignatureError
except Exception:
    VerifyKey = None
    BadSignatureError = Exception

START_TS = time.time()

class Settings(BaseSettings):
    CAMERA_INDEX: int = 0
    CAMERA_WIDTH: int = 1920
    CAMERA_HEIGHT: int = 1080
    CAMERA_FPS: int = 30

    REMOTE_BASE_URL: str
    API_TOKEN: str

    IMG_SIZE_DET: int = 640
    MIN_BOX_REL_AREA: float = 0.001
    STABLE_FRAMES: int = 5
    CONF_ACCEPT: float = 0.95
    CONF_ALT_MIN: float = 0.80

    MAX_ITEMS: int = 10
    MAX_PHOTOS_PER_ID: int = 50
    FREE_DISK_MIN_PERCENT: int = 20

    MODEL_DIR: str = "models/current"
    DATA_DIR: str = "data"
    REQUEST_TIMEOUT: int = 120
    LOG_DIR: str = "logs"

    OUTBOX_DIR: str = "outbox"
    OUTBOX_TTL_DAYS: int = 7
    OUTBOX_MAX_GB: int = 10

    AUTO_BG_CALIBRATION_IDLE_SEC: int = 30

    RERANKER_ENABLED: bool = True
    RERANKER_METHOD: str = "hist"
    RERANKER_EMB_MODEL: str = "embeddings/model.xml"
    RERANKER_INDEX: str = "embeddings/prototypes.json"

    MODEL_SIGN_PUBKEY_PATH: str = "license/model_signing_pubkey.pem"
    ENFORCE_LICENSE: bool = False
    LICENSE_PUBKEY_PATH: str = "license/license_pubkey.pem"
    LICENSE_FILE: str = "license/license.json"
    LICENSE_SIG: str = "license/license.sig"

    class Config:
        env_file = ".env"

settings = Settings()
for p in [settings.MODEL_DIR, f"{settings.DATA_DIR}/new_items", f"{settings.DATA_DIR}/collected", settings.LOG_DIR, settings.OUTBOX_DIR, "embeddings", "license"]:
    pathlib.Path(p).mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s: %(message)s",
    handlers=[
        logging.FileHandler(pathlib.Path(settings.LOG_DIR, "local_service.log"), encoding="utf-8"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("local")

def require_token(x_api_token: str = Header(..., alias="X-API-Token")):
    if x_api_token != settings.API_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid API token")
    return True

class LicenseManager:
    def __init__(self):
        self.state = "unchecked"
        self.details = ""
    def verify(self):
        pub_path = pathlib.Path(settings.LICENSE_PUBKEY_PATH)
        lic_path = pathlib.Path(settings.LICENSE_FILE)
        sig_path = pathlib.Path(settings.LICENSE_SIG)
        if not (pub_path.exists() and lic_path.exists() and sig_path.exists()):
            self.state = "missing"; self.details = "license files not found"
            return settings.ENFORCE_LICENSE is False
        if VerifyKey is None:
            self.state = "skip"; return True
        try:
            pub = VerifyKey(pub_path.read_bytes())
            payload = lic_path.read_bytes()
            signature = sig_path.read_bytes()
            pub.verify(payload, signature)
            self.state = "ok"; self.details = "ok"
            return True
        except Exception as e:
            self.state = "bad"; self.details = str(e)
            return settings.ENFORCE_LICENSE is False

license_manager = LicenseManager()
if not license_manager.verify():
    raise SystemExit(f"License verification failed: {license_manager.details}")

class ConfidenceCalibrator:
    def __init__(self):
        self.bins: T.List[T.Tuple[float,float]] = []
        self.method = "identity"
        self.path = pathlib.Path(settings.MODEL_DIR) / "calibration.json"
        if self.path.exists():
            try:
                obj = json.loads(self.path.read_text(encoding="utf-8"))
                self.method = obj.get("method","identity")
                self.bins = obj.get("bins", [])
            except Exception as e:
                log.warning("Calibration load failed: %s", e)
    def apply(self, conf: float) -> float:
        if not self.bins or self.method == "identity":
            return conf
        # bins: [[threshold, value], ...], thresholds ascending
        v = conf
        prev = self.bins[0][1]
        for th, val in self.bins:
            if conf < th:
                return max(0.0, min(1.0, prev))
            prev = val
        return max(0.0, min(1.0, self.bins[-1][1]))

class ModelManager:
    def __init__(self, model_dir: str, imgsz: int):
        self.model_dir = pathlib.Path(model_dir)
        self.imgsz = imgsz
        self._lock = threading.RLock()
        self.calibrator = ConfidenceCalibrator()
        self._load_model()
    def _load_model(self):
        with self._lock:
            xml_path = self.model_dir / "model.xml"
            labels_path = self.model_dir / "labels.json"
            if not xml_path.exists():
                self.model = None; self.names = {}; return
            self.model = YOLO(str(xml_path))
            if labels_path.exists():
                self.names = {int(k): v for k,v in json.loads(labels_path.read_text(encoding="utf-8")).items()}
            else:
                self.names = getattr(self.model, "names", {})
            self.calibrator = ConfidenceCalibrator()
            log.info("Model loaded: %s, classes=%d, calibration=%s", xml_path, len(self.names), self.calibrator.method)
    def validate_model_dir(self, candidate_dir: pathlib.Path) -> bool:
        try:
            xml = candidate_dir / "model.xml"
            if not xml.exists(): return False
            test = YOLO(str(xml))
            dummy = np.zeros((self.imgsz, self.imgsz, 3), dtype=np.uint8)
            _ = test.predict(source=dummy, imgsz=self.imgsz, verbose=False)
            return True
        except Exception as e:
            log.error("Model validation failed: %s", e); return False
    def swap_model(self, new_dir: pathlib.Path):
        with self._lock:
            old_dir = self.model_dir
            backup = old_dir.with_suffix(".bak")
            if old_dir.exists():
                if backup.exists(): shutil.rmtree(backup, ignore_errors=True)
                os.replace(str(old_dir), str(backup))
            os.replace(str(new_dir), str(old_dir))
            self._load_model()
            shutil.rmtree(backup, ignore_errors=True)
    def detect(self, frame_bgr: np.ndarray):
        with self._lock:
            if self.model is None:
                return None
            return self.model.predict(source=frame_bgr, imgsz=self.imgsz, verbose=False)

model_manager = ModelManager(settings.MODEL_DIR, settings.IMG_SIZE_DET)

class Reranker:
    def __init__(self):
        self.enabled = settings.RERANKER_ENABLED
        self.method = settings.RERANKER_METHOD.lower()
        self.protos = []
        self.dim = None
        self.ok = False
        if not self.enabled:
            log.info("Reranker disabled"); return
        idx = pathlib.Path(settings.RERANKER_INDEX)
        if not idx.exists():
            log.warning("Reranker index not found: %s", idx); self.enabled=False; return
        try:
            self.protos = json.loads(idx.read_text(encoding="utf-8"))
            if not self.protos: raise ValueError("empty prototypes")
            self.dim = len(self.protos[0]["vec"]); self.ok=True
            log.info("Reranker loaded: %d prototypes", len(self.protos))
        except Exception as e:
            log.error("Reranker load failed: %s", e); self.enabled=False
    def _feat_hist(self, crop_bgr: np.ndarray) -> np.ndarray:
        hsv = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv],[0,1,2],None,[8,8,8],[0,180,0,256,0,256])
        hist = cv2.normalize(hist, None).flatten().astype(np.float32); return hist
    def _cos(self, a,b): return float(np.dot(a,b)/((np.linalg.norm(a)+1e-8)*(np.linalg.norm(b)+1e-8)))
    def rerank(self, frame_bgr: np.ndarray, per_class: dict) -> dict:
        if not self.enabled or not self.ok: return per_class
        new_pc = {k: dict(v) for k,v in per_class.items()}
        for k,v in per_class.items():
            boxes = v.get("boxes", [])
            if not boxes: continue
            areas = [(x2-x1)*(y2-y1) for (x1,y1,x2,y2) in boxes]
            i = int(np.argmax(areas)); x1,y1,x2,y2=boxes[i]
            x1=max(0,x1); y1=max(0,y1); crop=frame_bgr[y1:y2,x1:x2]
            if crop.size==0: continue
            feat = self._feat_hist(crop)
            # best similarity for same id if present among prototypes
            best_sim = 0.0
            for p in self.protos:
                s = self._cos(feat, np.array(p["vec"], dtype=np.float32))
                if p["id"]==k and s>best_sim: best_sim = s
            delta = (best_sim - 0.5) * 0.06  # [-0.03,+0.03]
            new_pc[k]["max_conf"] = float(np.clip(v["max_conf"] + delta, 0.0, 1.0))
        return new_pc

reranker = Reranker()

class ClassStability:
    def __init__(self, stable_frames: int, alt_min: float):
        self.stable_frames=stable_frames; self.alt_min=alt_min; self.counts={}
    def update(self, frame_scores: T.Dict[str,float]):
        present=set([k for k,v in frame_scores.items() if v>=self.alt_min])
        for cls in present: self.counts[cls]=self.counts.get(cls,0)+1
        for cls in list(self.counts.keys()):
            if cls not in present: self.counts[cls]=0
    def stable_classes(self)->T.List[str]:
        return [k for k,c in self.counts.items() if c>=self.stable_frames]

class PresenceWatcher:
    def __init__(self, diff_value: int = 25, fraction_threshold: float = 0.02, alpha: float = 0.02):
        self.diff_value=diff_value; self.fraction_threshold=fraction_threshold; self.alpha=alpha; self.bg=None
    def is_present(self, gray: np.ndarray) -> bool:
        if self.bg is None: self.bg=gray.astype(np.float32); return False
        cv2.accumulateWeighted(gray, self.bg, self.alpha)
        diff = cv2.absdiff(gray, cv2.convertScaleAbs(self.bg))
        return (diff>self.diff_value).sum()/diff.size > self.fraction_threshold

class Outbox:
    def __init__(self, dir_path: pathlib.Path):
        self.dir = dir_path; self.dir.mkdir(parents=True, exist_ok=True)
        self.stop_event=threading.Event()
        self.thread=threading.Thread(target=self._run, daemon=True); self.thread.start()
    def _disk_gb(self)->float:
        return sum(p.stat().st_size for p in self.dir.glob("*.*"))/(1024**3)
    def enqueue(self, endpoint: str, data: bytes, filename: str, headers: dict):
        job_id = datetime.utcnow().strftime("%Y%m%d%H%M%S%f")
        (self.dir/f"{job_id}.bin").write_bytes(data)
        (self.dir/f"{job_id}.job").write_text(json.dumps({
            "id":job_id,"endpoint":endpoint,"filename":filename,"headers":headers,
            "created_at": datetime.utcnow().isoformat()+"Z","attempts":0
        }), encoding="utf-8")
    def _run(self):
        while not self.stop_event.is_set():
            try:
                # enforce size quota
                while self._disk_gb()>settings.OUTBOX_MAX_GB:
                    jobs=sorted(self.dir.glob("*.job"), key=lambda p:p.stat().st_mtime)
                    if not jobs: break
                    j=jobs[0]; jid=j.stem
                    (self.dir/f"{jid}.bin").unlink(missing_ok=True); j.unlink(missing_ok=True)
                for jf in sorted(self.dir.glob("*.job"), key=lambda p:p.stat().st_mtime):
                    job=json.loads(jf.read_text(encoding="utf-8"))
                    created = datetime.fromisoformat(job["created_at"].replace("Z",""))
                    if (datetime.utcnow()-created).days>settings.OUTBOX_TTL_DAYS:
                        (self.dir/f"{job['id']}.bin").unlink(missing_ok=True); jf.unlink(missing_ok=True); continue
                    url=f"{settings.REMOTE_BASE_URL.rstrip('/')}/{job['endpoint'].lstrip('/')}"
                    data=(self.dir/f"{job['id']}.bin").read_bytes()
                    files={"file":(job["filename"], io.BytesIO(data), "application/zip")}
                    try:
                        resp=requests.post(url, files=files, headers=job["headers"], timeout=settings.REQUEST_TIMEOUT)
                        if resp.status_code==200:
                            (self.dir/f"{job['id']}.bin").unlink(missing_ok=True); jf.unlink(missing_ok=True)
                        else:
                            job["attempts"]+=1; jf.write_text(json.dumps(job), encoding="utf-8")
                    except Exception:
                        job["attempts"]+=1; jf.write_text(json.dumps(job), encoding="utf-8")
                time.sleep(10)
            except Exception as e:
                log.exception("Outbox error: %s", e); time.sleep(10)

outbox = Outbox(pathlib.Path(settings.OUTBOX_DIR))

class CameraService:
    def __init__(self):
        self.cap=None; self.thread=None; self.stop_event=threading.Event()
        self.presence=PresenceWatcher(); self.stability=ClassStability(settings.STABLE_FRAMES, settings.CONF_ALT_MIN)
        self.last_state={"type":"no_event"}; self.event_queue=queue.Queue(maxsize=64)
        self.new_item_active=False; self.new_item_id=None; self.new_item_saved=0; self.min_new_photos=50
        self.save_collected_every=5; self._frame_id=0; self.last_activity_ts=time.time(); self.last_gray_frame=None
        self.inf_times=[]  # ms history
    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.stop_event.clear(); self.thread=threading.Thread(target=self._run, daemon=True); self.thread.start()
    def stop(self):
        self.stop_event.set(); 
        if self.thread: self.thread.join(timeout=2)
    def _can_collect(self, item_id:str)->bool:
        u=psutil.disk_usage(pathlib.Path(settings.DATA_DIR))
        if int(100*u.free/u.total)<settings.FREE_DISK_MIN_PERCENT: return False
        folder=pathlib.Path(settings.DATA_DIR,"collected",item_id)
        if folder.exists():
            n=sum(1 for _ in folder.glob("*.jpg"))
            if n>=settings.MAX_PHOTOS_PER_ID: return False
        return True
    def _save_frame(self, subdir:str, item_id:str, frame_bgr:np.ndarray):
        if not self._can_collect(item_id): return
        ts=datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
        out_dir=pathlib.Path(settings.DATA_DIR, subdir, item_id)
        out_dir.mkdir(parents=True, exist_ok=True)
        cv2.imwrite(str(out_dir/f"{ts}.jpg"), frame_bgr)
    def _emit(self, payload:dict):
        self.last_state=payload
        try:
            self.event_queue.put_nowait(payload)
        except queue.Full:
            try: _=self.event_queue.get_nowait(); self.event_queue.put_nowait(payload)
            except Exception: pass
    def start_new_item_session(self, item_id:str, min_photos:int):
        if self.new_item_active: raise RuntimeError("session active")
        self.new_item_active=True; self.new_item_id=item_id; self.new_item_saved=0
        self.min_new_photos=max(50,int(min_photos))
        pathlib.Path(settings.DATA_DIR, "new_items", item_id).mkdir(parents=True, exist_ok=True)
    def end_new_item_session(self):
        self.new_item_active=False; self.new_item_id=None
    def _apply_detection_logic(self, frame_bgr: np.ndarray):
        H,W=frame_bgr.shape[:2]; t0=time.time()
        results=model_manager.detect(frame_bgr)
        inf_ms=int((time.time()-t0)*1000); self.inf_times.append(inf_ms)
        if len(self.inf_times)>200: self.inf_times=self.inf_times[-200:]
        ts=datetime.utcnow().isoformat()+"Z"
        if results is None:
            self._emit({"type":"model_absent","ts":ts}); return
        r=results[0]
        if not hasattr(r,"boxes") or r.boxes is None or r.boxes.shape[0]==0:
            self.stability.update({}); self._emit({"type":"object_absent","ts":ts}); return

        per_class={}
        for b in r.boxes:
            conf=float(b.conf.item()); cls_idx=int(b.cls.item())
            name=model_manager.names.get(cls_idx, str(cls_idx))
            x1,y1,x2,y2=b.xyxy.cpu().numpy().reshape(-1)
            area=(max(0.0,x2-x1)*max(0.0,y2-y1))/(W*H+1e-9)
            if area<settings.MIN_BOX_REL_AREA: continue
            if conf>=settings.CONF_ALT_MIN:
                d=per_class.setdefault(name, {"max_conf":0.0,"count":0,"boxes":[]})
                d["max_conf"]=max(d["max_conf"], conf); d["count"]+=1; d["boxes"].append([int(x1),int(y1),int(x2),int(y2)])

        self.stability.update({k:v["max_conf"] for k,v in per_class.items()})
        per_class = reranker.rerank(frame_bgr, per_class)

        # apply calibration
        for k in list(per_class.keys()):
            per_class[k]["max_conf"] = model_manager.calibrator.apply(per_class[k]["max_conf"])

        items=[{"item_id":k,"confidence":round(v["max_conf"],4),"count":v["count"],"boxes":v["boxes"]}
               for k,v in per_class.items() if v["max_conf"]>=settings.CONF_ALT_MIN and self.stability.counts.get(k,0)>=settings.STABLE_FRAMES]
        accepted=[it for it in items if it["confidence"]>=settings.CONF_ACCEPT]
        accepted.sort(key=lambda x:x["confidence"], reverse=True)
        truncated=False
        if len(accepted)>settings.MAX_ITEMS:
            accepted=accepted[:settings.MAX_ITEMS]; truncated=True
        candidates=[{"item_id":it["item_id"],"confidence":it["confidence"]}
                    for it in items if settings.CONF_ALT_MIN<=it["confidence"]<settings.CONF_ACCEPT]
        candidates.sort(key=lambda x:x["confidence"], reverse=True)
        alternates=candidates[:4]

        if accepted:
            ev={"type":"ok_multi","ts":ts,"items":accepted,"alternates":alternates,"truncated":truncated}
            self._emit(ev)
            if self._frame_id%self.save_collected_every==0:
                for it in accepted: self._save_frame("collected", it["item_id"], frame_bgr)
            if self.new_item_active and self.new_item_id in [it["item_id"] for it in accepted]:
                self._save_frame("new_items", self.new_item_id, frame_bgr); self.new_item_saved+=1
        else:
            if candidates:
                self._emit({"type":"low_confidence_multi","ts":ts,"candidates":candidates})
            else:
                self._emit({"type":"object_absent","ts":ts})
    def _run(self):
        self.cap=cv2.VideoCapture(settings.CAMERA_INDEX, cv2.CAP_DSHOW if os.name=="nt" else 0)
        if not self.cap.isOpened(): raise RuntimeError(f"Camera open failed index={settings.CAMERA_INDEX}")
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, settings.CAMERA_WIDTH)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, settings.CAMERA_HEIGHT)
        self.cap.set(cv2.CAP_PROP_FPS, settings.CAMERA_FPS)
        try:
            while not self.stop_event.is_set():
                ok, frame = self.cap.read()
                if not ok: time.sleep(0.01); continue
                self._frame_id += 1
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                self.last_gray_frame = gray
                present = self.presence.is_present(gray)
                if present:
                    self.last_activity_ts = time.time()
                    try: self._apply_detection_logic(frame)
                    except Exception as e: log.exception("Detect error: %s", e)
                else:
                    self._emit({"type":"object_absent","ts":datetime.utcnow().isoformat()+"Z"})
                time.sleep(1.0/max(15, settings.CAMERA_FPS))
        finally:
            if self.cap: self.cap.release()

camera=CameraService(); camera.start()

def _bg_calibrator():
    while True:
        try:
            idle=time.time()-camera.last_activity_ts
            if idle>=settings.AUTO_BG_CALIBRATION_IDLE_SEC and camera.last_gray_frame is not None:
                camera.presence.bg=camera.last_gray_frame.astype(np.float32)
                log.info("Background recalibrated after idle %ds", settings.AUTO_BG_CALIBRATION_IDLE_SEC)
                camera.last_activity_ts=time.time()
            time.sleep(5)
        except Exception as e:
            log.exception("BG calibrator error: %s", e); time.sleep(5)
threading.Thread(target=_bg_calibrator, daemon=True).start()

def zip_dir(src: pathlib.Path)->bytes:
    buf=io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in src.rglob("*"):
            if p.is_file():
                zf.write(p, arcname=str(p.relative_to(src)))
    buf.seek(0); return buf.read()

def enqueue_zip(endpoint: str, zipb: bytes, filename: str):
    headers={"X-API-Token": settings.API_TOKEN}
    outbox.enqueue(endpoint, zipb, filename, headers)

app = FastAPI(title="Local YOLO(OpenVINO) Service v3", version="2.3")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/health")
def health():
    model_loaded = model_manager.model is not None
    return {"status":"ok","model_loaded":model_loaded,"camera":{"width":settings.CAMERA_WIDTH,"height":settings.CAMERA_HEIGHT,"fps":settings.CAMERA_FPS},"license":license_manager.state}

@app.get("/diagnostics")
def diagnostics():
    usage = psutil.disk_usage(pathlib.Path(settings.DATA_DIR))
    jobs = list(pathlib.Path(settings.OUTBOX_DIR).glob("*.job"))
    inf_ms = camera.inf_times[:] or [0]
    diag = {
        "uptime_sec": int(time.time()-START_TS),
        "model_dir": str(pathlib.Path(settings.MODEL_DIR).resolve()),
        "classes": len(getattr(model_manager, "names", {})),
        "calibration": getattr(model_manager.calibrator, "method", "none"),
        "fps_estimate": round(1000.0/max(1, int(np.median(inf_ms))), 2) if inf_ms else None,
        "inf_ms_p50": int(np.percentile(inf_ms,50)),
        "inf_ms_p95": int(np.percentile(inf_ms,95)),
        "outbox_jobs": len(jobs),
        "outbox_size_mb": round(sum((pathlib.Path(settings.OUTBOX_DIR)/j.name.replace(".job",".bin")).stat().st_size for j in jobs if (pathlib.Path(settings.OUTBOX_DIR)/j.name.replace(".job",".bin")).exists())/ (1024**2),2),
        "disk_free_percent": int(100*usage.free/usage.total),
        "last_event": camera.last_state.get("type"),
        "proto_count": len(reranker.protos) if reranker.enabled else 0,
        "reranker": reranker.method if reranker.enabled else "disabled"
    }
    return diag

@app.get("/metrics")
def metrics():
    u = psutil.disk_usage(pathlib.Path(settings.DATA_DIR))
    jobs = len(list(pathlib.Path(settings.OUTBOX_DIR).glob("*.job")))
    inf_ms = camera.inf_times[:] or [0]
    lines = []
    lines.append(f'local_uptime_seconds {int(time.time()-START_TS)}')
    lines.append(f'local_disk_free_percent {int(100*u.free/u.total)}')
    lines.append(f'local_outbox_jobs {jobs}')
    lines.append(f'local_infer_ms_p50 {int(np.percentile(inf_ms,50))}')
    lines.append(f'local_infer_ms_p95 {int(np.percentile(inf_ms,95))}')
    return PlainTextResponse("\n".join(lines))

@app.get("/identify/current")
def identify_current(): return identify_primary()

@app.get("/identify/primary")
def identify_primary():
    s=camera.last_state or {"type":"no_event"}
    if s.get("type")=="model_absent": return JSONResponse(status_code=503, content=s)
    if s.get("type")=="object_absent": return JSONResponse(status_code=204, content=s)
    if s.get("type")=="low_confidence_multi": return JSONResponse(status_code=422, content=s)
    if s.get("type")=="ok_multi":
        items=s.get("items",[]); if not items: return JSONResponse(status_code=204, content={"type":"object_absent"})
        primary=items[0]; additional=items[1:10]
        return {"type":"ok_primary","ts":s.get("ts"),"item_id":primary["item_id"],"confidence":primary["confidence"],"additional_items":additional,"alternates":s.get("alternates",[])}
    return JSONResponse(status_code=204, content={"type":"object_absent"})

@app.get("/identify/multi")
def identify_multi():
    s=camera.last_state or {"type":"no_event"}
    if s.get("type")=="model_absent": return JSONResponse(status_code=503, content=s)
    if s.get("type")=="object_absent": return JSONResponse(status_code=204, content=s)
    if s.get("type")=="low_confidence_multi": return JSONResponse(status_code=422, content=s)
    if s.get("type")=="ok_multi": return s
    return JSONResponse(status_code=204, content={"type":"object_absent"})

@app.websocket("/ws/detections")
async def ws_detections(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            try:
                ev=camera.event_queue.get(timeout=1.0); await ws.send_json(ev)
            except queue.Empty:
                await ws.send_json({"type":"keepalive"})
    except WebSocketDisconnect:
        pass

@app.post("/products/new/start")
def start_new_product(min_photos:int=50, authorized: bool = Depends(require_token)):
    headers={"X-API-Token": settings.API_TOKEN}
    try:
        r=requests.post(f"{settings.REMOTE_BASE_URL}/products/register", headers=headers, timeout=settings.REQUEST_TIMEOUT)
        item_id = r.json()["item_id"] if r.status_code==200 else f"tmp_{int(time.time())}"
    except Exception:
        item_id = f"tmp_{int(time.time())}"
    camera.start_new_item_session(item_id, min_photos)
    return {"status":"started","item_id":item_id,"min_photos":camera.min_new_photos}

@app.get("/products/{item_id}/collect/progress")
def new_item_progress(item_id:str, authorized: bool = Depends(require_token)):
    if camera.new_item_id!=item_id or not camera.new_item_active:
        raise HTTPException(status_code=400, detail="Session inactive")
    return {"item_id":item_id,"saved":camera.new_item_saved,"required":camera.min_new_photos}

@app.post("/products/{item_id}/collect/finish-and-upload")
def finish_and_upload_new_item(item_id:str, background: BackgroundTasks, authorized: bool = Depends(require_token)):
    if camera.new_item_id!=item_id or not camera.new_item_active:
        raise HTTPException(status_code=400, detail="Session inactive")
    if camera.new_item_saved<camera.min_new_photos:
        raise HTTPException(status_code=400, detail=f"Not enough photos: {camera.new_item_saved} < {camera.min_new_photos}")
    camera.end_new_item_session()
    def _task():
        src=pathlib.Path(settings.DATA_DIR,"new_items",item_id)
        if not src.exists(): return
        zipb=zip_dir(src); enqueue_zip("dataset/ingest_new_item", zipb, f"new_item_{item_id}.zip")
        shutil.rmtree(src, ignore_errors=True)
    background.add_task(_task)
    return {"status":"queued","item_id":item_id}

@app.post("/dataset/push-collected")
def push_collected(authorized: bool = Depends(require_token)):
    base=pathlib.Path(settings.DATA_DIR,"collected")
    if not base.exists(): return {"status":"nothing_to_send"}
    zipb=zip_dir(base); enqueue_zip("dataset/ingest_collected", zipb, "collected.zip")
    shutil.rmtree(base, ignore_errors=True); pathlib.Path(base).mkdir(parents=True, exist_ok=True)
    return {"status":"queued"}

@app.post("/model/sync")
def model_sync(authorized: bool = Depends(require_token)):
    headers={"X-API-Token": settings.API_TOKEN}; base=settings.REMOTE_BASE_URL.rstrip("/")
    meta=requests.get(f"{base}/model/latest/metadata", headers=headers, timeout=settings.REQUEST_TIMEOUT)
    if meta.status_code!=200: raise HTTPException(status_code=meta.status_code, detail=meta.text)
    model=requests.get(f"{base}/model/latest/download", headers=headers, timeout=settings.REQUEST_TIMEOUT)
    if model.status_code!=200: raise HTTPException(status_code=model.status_code, detail=model.text)
    sig_b64=model.headers.get("X-Model-Signature"); pub=pathlib.Path(settings.MODEL_SIGN_PUBKEY_PATH)
    if sig_b64 and pub.exists() and VerifyKey is not None:
        try:
            VerifyKey(pub.read_bytes()).verify(model.content, base64.b64decode(sig_b64))
        except BadSignatureError:
            raise HTTPException(status_code=400, detail="Bad model signature")
    tmp=pathlib.Path(tempfile.mkdtemp(prefix="model_dl_"))
    with zipfile.ZipFile(io.BytesIO(model.content), "r") as zf: zf.extractall(tmp)
    if not model_manager.validate_model_dir(tmp):
        shutil.rmtree(tmp, ignore_errors=True); raise HTTPException(status_code=400, detail="Model validation failed")
    # copy optional artifacts
    emb_dir=pathlib.Path("embeddings"); emb_dir.mkdir(parents=True, exist_ok=True)
    proto=tmp/"prototypes.json"
    if proto.exists(): shutil.copy2(proto, emb_dir/"prototypes.json")
    calib=tmp/"calibration.json"
    if calib.exists(): shutil.copy2(calib, pathlib.Path(settings.MODEL_DIR)/"calibration.json")
    model_manager.swap_model(tmp)
    return {"status":"ok","meta":meta.json()}

if __name__=="__main__":
    import uvicorn; uvicorn.run("app:app", host="0.0.0.0", port=8010, reload=False, log_level="info")
