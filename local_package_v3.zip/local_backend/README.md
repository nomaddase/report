# Local YOLO(OpenVINO) Service v3

- /identify/primary, /identify/multi
- /diagnostics (JSON), /metrics (Prometheus)
- Confidence calibration support via calibration.json
- Outbox store-and-forward, quotas, background calibration

Run:
```powershell
python -m uvicorn app:app --host 0.0.0.0 --port 8010
```
